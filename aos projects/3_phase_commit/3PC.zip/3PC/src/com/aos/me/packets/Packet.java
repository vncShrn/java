package com.aos.me.packets;

import java.io.Serializable;

/**
 * 
 * @author Vincy Shrine
 *
 */
public interface Packet extends Serializable {

}


