package com.aos.me.other;

/**
 * 
 * @author Vincy Shrine
 *
 */
public class Definitions {
	
	public static final int COMPUTE_Q_SIZE = 100;
	
	public static final int MAX_POOL_SIZE = 50;
	public static String COORDINATOR_HOSTNAME;
	public static boolean AM_I_COORDINATOR = Boolean.FALSE;
	public static int PID;
	
	public static int MAX_PROCESS = 0;
	public static int COORD_PORT = 8009;
	
	// TODO change last
	public static final int MIN_CS_REQ_COUNT = 2;
	public static final int MAX_CS_REQ_COUNT = 2;

	public static final int SOCKET_TIMEOUT = 1000;
	
	public static String thisHostName;

	

}

