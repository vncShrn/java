package com.aos.me.types;

import java.io.Serializable;

/**
 * 
 * @author Vincy Shrine
 *
 */
public interface Packet extends Serializable {

}


